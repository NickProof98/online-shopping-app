#include<stdio.h>
#include<string.h>
main()
{
 static int totalCost;
 int i,j,choice,c=1,a[9],cost[9];
 for(i=0;i<9;i++)
 a[i]=0;
 
 char str[100];
 char items[24][100]={"Ramly Burger chicken 70g",
	    "Ramly Burger Beef 70g",
		"Ramly Burger Buffalo 70g",
		"Ramly Oblong Burger Mutton 70g",
		"Ramly fish burger 70g",
		"Ramly Mince Chicken 70g",
		"Ramly Mince Beef 70g",
		"Ramly Frankfurter Chicken 70g",
		"Ramly Frankfurter Beef 70g",
		"Ramly Chicken Nuggets",
		"Ramly Beef Nuggets",
		"Ramly Fish Nuggets",
		"Ramly Tempura Chicken Nuggets",
		"Ramly shoestring",
		"Ramly crinklecut",
		"Ramly wedges",
		"Ramly Hashbrown",
		"Ramly tomato sauce",
		"Ramly chilli sauce",
		"Ramly bbq sauce",
		"Ramly black pepper sauce",
		"Ramly Mayonneise sauce",
		"Ramly Cheese Sauce",
		"Ramly Thousand island sauce"
 };
 printf("Please Enter Your Name\n");
 gets(str);
 printf("Hello %s, Welcome to our Online Shopping.\n",str);
 do{
  //C is 1 by default
  if(c==1){
  printf("Enter\n1 - Burger\n2 - Mince\n3 - Frankfurthers\n4 - Nuggets\n5 - Fries\n6 - Sauce\nAny other number to exit\n");
  scanf("%d",&choice);
  switch(choice)
  {
   case 1:
   {
    int burgerChoice;
    printf("Enter\n1 - Ramly Burger chicken 70g- RM10\n2 - Ramly Burger Beef 70g- RM12\n3 - Ramly Burger Buffalo 70g- RM16\n4 - Ramly Oblong Burger Mutton 70g- RM15\n5 - Ramly fish burger 70g- RM14\nAny other number to exit\n");
    scanf("%d",&burgerChoice);
    cost[0]=10;
    cost[1]=12;
    cost[2]=16;
    cost[3]=15;
    cost[4]=14;
    switch(burgerChoice)
    {
     case 1:
     {
      int num;
      printf("You chose Ramly Burger chicken 70g for RM10.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
      scanf("%d",&num);
      if(num==1)
      {
       a[0]++;
       totalCost+=10;
      }
      printf("Your Cost in Cart is %d\n",totalCost);
      break;
     }
     case 2:
     {
      int num;
      printf("You chose Ramly Burger beef 70g for RM12.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
      scanf("%d",&num);
      if(num==1)
      {
       a[1]++;
       totalCost+=12;
      }
      printf("Your Cost in Cart is %d\n",totalCost);
      break;
     }
     case 3:
     {
      int num;
      printf("You chose Ramly Burger Buffalo 70g for RM16.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
      scanf("%d",&num);
      if(num==1)
      {
       a[2]++;
       totalCost+=16;
      }
      printf("Your Cost in Cart is %d\n",totalCost);
      break;
     }
     case 4:
     	{
     	int num;
     	printf("You chose Ramly Oblong Burger Mutton for RM15.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
     	scanf("%d",&num);
     	if(num==1)
     	{
     		a[3]++;
     		totalCost+=15;
		}
		printf("Your Cost in Cart is %d\n",totalCost);
		break;
		 }
		case 5:
		{
		int num;
		printf("You chose Ramly Burger Fish 70g for RM14.Are you sure to buy.If 'Yes'Enter 1 else any number\n");
		scanf("%d",&num);
		if(num==1)
		{
			a[4]++;
			totalCost+=14;
		}
		printf("Your Cost in Cart is %d\n", totalCost);
		break;
	 } 
     default:{
      printf("Exit from Burger\n");
      break;
     }
    }
    break;
   }
   case 2:
   {
    int minceChoice;
    printf("Enter\n1 - Ramly Mince Chicken 70g - RM15\n2 - Ramly Mince Beef 70g - RM20\nAny other number to exit\n");
    scanf("%d",&minceChoice);
    cost[5]=15;
    cost[6]=20;
    switch(minceChoice)
    {
     case 1:
     {
      int num;
      printf("You chose Ramly Mince Chicken 70g for RM15.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
      scanf("%d",&num);
      if(num==1)
      {
       a[5]++;
       totalCost+=15;
      }
      printf("Your Cost in Cart is %d\n",totalCost);
      break;
     }
     case 2:
     {
      int num;
      printf("You chose Ramly Mince Beef 70g for RM20.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
      scanf("%d",&num);
      if(num==1)
      {
       a[6]++;
       totalCost+=20;
      }
      printf("Your Cost in Cart is %d\n",totalCost);
      break;
     }
     
     default:{
      printf("Exit from Mince\n");
      break;
     }
    }
    break;
   }
   case 3:
   {
    int frankfurterChoice;
    printf("Enter\n1 - Ramly Frankfurter Chicken 70g - RM20\n2 - Ramly Frankfurter Beef 70g - RM25\nAny other number to exit\n");
    scanf("%d",&frankfurterChoice);
    cost[7]=20;
    cost[8]=25;
    switch(frankfurterChoice)
    {
     case 1:
     {
      int num;
      printf("You chose to buy Ramly Frankfurter Chicken 70g for RM20.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
      scanf("%d",&num);
      if(num==1)
      {
       a[7]++;
       totalCost+=20;
      }
      printf("Your Cost in Cart is %d\n",totalCost);
      break;
     }
     case 2:
     {
      int num;
      printf("You chose to buy Ramly Frankfurter Beef 70g for RM25.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
      scanf("%d",&num);
      if(num==1)
      {
       a[8]++;
       totalCost+=25;
      }
      printf("Your Cost in Cart is %d\n",totalCost);
      break;
     }
     
     default:{
      printf("Exit from Frankfurter\n");
      break;
     }
     case 4:
     	{
     	int nuggetChoice;
     	printf("Enter\n1 - Ramly Chicken Nuggets - RM15\n2 - Ramly Beef Nuggets - RM20\n3 - Ramly Fish Nuggets - RM17\n4 - Ramly Tempura Chicken Nuggets - RM17\nAny other number to exit\n");
    scanf("%d",&nuggetChoice);
    cost[9]=15;
    cost[10]=20;
    cost[11]=17;
    cost[12]=17;
   	 switch(nuggetChoice)
     {
    	case 1:
    	{
    		int num;
    		printf("You chose to buy Ramly Chicken Nuggets for RM15.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
    		scanf("%d",&num);
    		if(num==1)
    		{
    			a[9]++;
    			totalCost+=15;
			}
			 printf("Your Cost in Cart is %d\n",totalCost);
             break;
		}
		
		case 2:
			{
				int num;
				printf("You chose to buy Ramly Beef Nuggets for RM20.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
				scanf("%d",&num);
				if(num==1)
				{
					a[10]++;
					totalCost+=20;
				}
				printf("Your Cost in Cart is %d\n",totalCost);
				break;
			}
			
			case 3:
				{
					int num;
					printf("You chose to buy Ramly Fish Nuggets for RM17.Are you sure to buy.If 'Yes' Enter 1 else any number\n");
					scanf("%d",&num);
					if(num==1)
					{
						a[11]++;
						totalCost+=17;
					}
					printf("Your Cost in Cart is %d\n", totalCost);
					break;
				}
			case 4:
				{
					int num;
					printf("You chose to buy Ramly Tempura Chicken Nuggets for RM17.Are you sure to buy.If'Yes'Enter 1 else any number\n");
					scanf("%d",&num);
					if(num==1)
					{
						a[12]++;
						totalCost+=17;
					}
					printf("Your Cost in Cart is %d\n", totalCost);
					break;
				}
				default:{
					printf("Exit from Nugget\n");
					break;
				}
			
			case 5:
				{
					int friesChoice;
					printf("Enter\n1 - Ramly Shoestring - RM10\n2 - Ramly Crinklecut - RM10\n3 - Ramly wedges - RM7\n4 - Ramly Hashbrown - RM15\nAny other number to exit\n");
					scanf("%d",friesChoice);
					cost[13]=10;
					cost[14]=10;
					cost[15]=7;
					cost[16]=15;
					switch (friesChoice)
					{
						case 1:
							{
								int num;
								printf("You chose to buy Ramly Shoestring for RM10.Are you sure to buy.If'Yes'Enter 1 else any number\n");
								scanf("%d",&num);
								if(num==1)
								{
									a[13]++;
									totalCost+=10;
								}
								printf("Your Cost in Cart is %d\n", totalCost);
								break;
							}
						case 2:
							{
								int num;
								printf("You chose to buy Ramly Crinklecut for RM10.Are you sure to buy.If'Yes'Enter 1 else any number\n");
								scanf("%d",&num);
								if(num==1)
								{
									a[14]++;
									totalCost+=10;
								}
								printf("Your Cost in Cart is %d\n", totalCost);
								break;
							}
							
						case 3:
							{
								int num;
								printf("You chose to buy Ramly wedges for RM7.Are you sure to buy.If 'Yes'Enter 1 else any number\n");
								scanf("%d",&num);
								if(num==1)
								{
									a[15]++;
									totalCost+=7;
								}
								printf("Your Cost in Cart is %d\n", totalCost);
								break;
							}
						case 4:
							{
								int num;
								printf("You chose to buy Ramly Hashbrown for RM15.Are you sure to buy.If'Yes'Enter 1 else any number\n");
								scanf("%d",&num);
								if (num==1)
								{
									a[16]++;
									totalCost+=15;
								}
								printf("Your Cost in Cart is %d\n", totalCost);
								break;
							}
							default:{
								printf("Exit from fries\n");
								break;
							}
						case 6:
							{
								int sauceChoice;
								printf("Enter\n1 - Ramly tomato sauce - RM3/n2 - Ramly chilli sauce - RM3/n3 - Ramly bbq sauce - RM4\n4 - Ramly black pepper sauce - RM5\n5 - Ramly Mayonneise sauce - RM2\n6 - Ramly cheese sauce - RM6\n7 - Ramly thousand island sauce - RM8\nAny other number to exit\n");
								scanf("%d",sauceChoice);
								cost[17]=3;
								cost[18]=3;
								cost[19]=4;
								cost[20]=5;
								cost[21]=2;
								cost[22]=6;
								cost[23]=8;
								switch (sauceChoice)
								{
									case 1:
										{
											int num;
											printf("You chose to buy Ramly tomato sauce for RM3.Are you sure to buy. If 'Yes'Enter 1 else any number\n");
											scanf("%d",&num);
											if(num==1)
											{
												a[17]++;
												totalCost+=3;
											}
										    printf("Your Cost in Cart is %d\n", totalCost);
										    break;
										}
									case 2:
										{
											int num;
											printf("You chose to buy Ramly chilli sauce for RM3.Are you sure to buy. If 'Yes'Enter 1 else any number\n");
											scanf("%d",&num);
											if(num==1)
											{
												a[18]++;
												totalCost+=3;
											}
											printf("Your Cost in Cart is %d\n", totalCost);
											break;
										}
									case 3:
										{
											int num;
											printf("You chose to buy Ramly bbq sauce for RM4.Are you sure to buy. If 'Yes'Enter 1 else any number\n");
											scanf("%d",&num);
											if(num==1)
											{
												a[19]++;
												totalCost+=4;
											}
											printf("Your Cost in Cart is %d\n", totalCost);
											break;
										}
									case 4:
										{
											int num;
											printf("You chose to buy Ramly black pepper sauce for RM5.Are you sure to buy. If 'Yes'Enter 1 else any number\n");
											scanf("%d",&num);
											if(num==1)
											{
												a[20]++;
												totalCost+=5;
											}
											printf("Your Cost in Cart is %d\n", totalCost);
											break;
										}
									case 5:
										{
											int num;
											printf("You chose to buy Ramly Mayonneise sauce for RM2.Are you sure to buy. If 'Yes'Enter 1 else any number\n");
											scanf("%d",&num);
											if (num==1)
											{
												a[21]++;
												totalCost+=2;
											}
											printf("Your Cost in Cart is %d\n", totalCost);
											break;
										}
									case 6:
										{
											int num;
											printf("You chose to buy Ramly cheese sauce for RM6.Are you sure to buy.If 'Yes'Enter 1 else any number\n");
											scanf("%d",&num);
											if(num==1)
											{
												a[22]++;
												totalCost+=6;
											
											}
											printf("Your Cost in Cart is %d\n", totalCost);
											break;
										}
										
									case 7:
										{
											int num;
											printf("You chose to buy Ramly thousand island sauce for RM8.Are you sure to buy. If 'Yes'Enter 1 else any number\n");
											scanf("%d",&num);
											if(num==1)
											{
												a[23]++;
												totalCost+=8;
											}
											printf("Your Cost in Cart is %d\n", totalCost);
										}
										default:{
											printf("Exit from sauce\n");
											break;
										}
								}
							}
					}
				}
    	}
		}
    }
    break;
   }
   
   default:
   {
    printf("Enter Valid Categories Choice\n");
    break;
   }
  }
  printf("%s's cart\n",str);
  printf("Id\tItems\t\t\tQuantity\t\t\tCost\n");
  for(i=0;i<9;i++)
  {
   if(a[i]!=0)
   {
    printf("%d\t%s\t\t%d\t\t\t%d\n",i,items[i],a[i],(cost[i]*a[i]));
   }
  }
  printf("Total Cost\t\t\t\t\t%d\n",totalCost);
  printf("If you wish to buy anything more Enter\n1 to Add Item\n2 to Delete Items \nAny other number to Exit\n");
  scanf("%d",&c);
 }
  if(c==2)
  {
   int id;
   printf("Enter id to delete item\n");
   scanf("%d",&id);
   if(id<9&&id>0){
   totalCost=totalCost-(cost[id]*a[id]);
   a[id]=0;
   }
   else{
    printf("Enter Valid id\n");
   }
       printf("Revised Items \n");
       printf("Id\tItems\t\t\tQuantity\t\tCost\n");
            for(i=0;i<9;i++)
      {
     if(a[i]!=0)
      {
    printf("%d\t%s\t\t%d\t\t%d\n",i,items[i],a[i],(cost[i]*a[i]));
      }
     }
        printf("Total Cost\t\t\t\t\t%d\n",totalCost);
        printf("If you wish to buy anything more Enter\n1 to Add Item\n2 to Delete Items \nAny other number to Exit\n");
     scanf("%d",&c);
  }
  
 }while(c==1 || c==2);
 printf("Your Final Cost is %d\n",totalCost);
 printf("Thanks %s for Choosing Us and Visit us again.\n",str);
 
}